package com.virtusa.banking.models;

public class Utils {

	public static long generateID() {
		return System.currentTimeMillis();
	}
}
