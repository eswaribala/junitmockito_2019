package com.virtusa.banking.models;

public class Payment {
	private boolean isInit() {
		return false;
	}
	private String reverse(String s) {
		//return new StringBuilder(s).reverse().toString();
		return null;
	}
	public boolean checkStatus() {
		return isInit();
	}
	public String doReverse(String s) {
		return reverse(s);
	}
}