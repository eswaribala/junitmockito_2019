package com.virtusa.banking.models;

public class HSBCUser {
	
	private long mobileNo;
	private String name;
	
	public HSBCUser() {
		super();
	}
	public HSBCUser(long mobileNo, String name) {
		super();
		this.mobileNo = mobileNo;
		this.name = name;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	

}
