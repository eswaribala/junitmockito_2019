package com.virtusa.banking.models;

public final class Data {
	public final String reverse(String s) {
		return new StringBuffer(s).reverse().toString();
	}
}