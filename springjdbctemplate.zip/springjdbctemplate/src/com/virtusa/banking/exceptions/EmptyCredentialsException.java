package com.virtusa.banking.exceptions;

public class EmptyCredentialsException extends RuntimeException{

	public EmptyCredentialsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
