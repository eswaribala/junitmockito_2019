package com.virtusa.banking.dao.implementations;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.virtusa.banking.dao.interfaces.HSBCUserDao;
import com.virtusa.banking.models.HSBCUser;
@Repository
public class HSBCUserImpl implements HSBCUserDao{

	@Autowired
	private JdbcTemplate jdbcTemplate;
	private boolean status;
	
	@Override
	public boolean addUser(HSBCUser user) {
		// TODO Auto-generated method stub
		int result=jdbcTemplate.update("insert into HSBCUser values(?,?)",user.getName(),user.getMobileNo());
		if(result>0)
		  status=true;		
		return status;
	}

	@Override
	public List<HSBCUser> getAllUsers() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from hsbcuser", new BeanPropertyRowMapper<HSBCUser>(HSBCUser.class));		
		
	}

	@Override
	public HSBCUser getUserByMobileNumber(long mobileNo) {
		String sql = "SELECT * FROM hsbcuser WHERE mobileNo = ?";
		
        return jdbcTemplate.queryForObject(sql, new Object[]{mobileNo}, (rs, rowNum) ->
                new HSBCUser(
                        rs.getLong("mobileNo"),
                        rs.getString("name")
                       
                ));
	}

}
