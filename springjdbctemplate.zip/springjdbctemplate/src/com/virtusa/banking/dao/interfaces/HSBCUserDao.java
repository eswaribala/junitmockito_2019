package com.virtusa.banking.dao.interfaces;

import java.util.List;

import com.virtusa.banking.exceptions.EmptyCredentialsException;
import com.virtusa.banking.models.HSBCUser;

public interface HSBCUserDao {
	
	boolean addUser(HSBCUser user);
	List<HSBCUser> getAllUsers();
	HSBCUser getUserByMobileNumber(long mobileNumber) throws EmptyCredentialsException;

}
