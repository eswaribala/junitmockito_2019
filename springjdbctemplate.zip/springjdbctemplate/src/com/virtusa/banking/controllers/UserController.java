package com.virtusa.banking.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.virtusa.banking.models.HSBCUser;
import com.virtusa.banking.services.HSBCUserService;

@Controller
public class UserController {
	@Autowired
	private HSBCUserService userService;
	
	@GetMapping("/")
	public String home()
	{
		return "adduser";
	}
	
	@PostMapping("/adduserdata")
	public String addUserData(@RequestParam long mobileNo, @RequestParam String name)
	{
		HSBCUser userObj=new HSBCUser();
		userObj.setMobileNo(mobileNo);
		userObj.setName(name);
		if(userService.addUser(userObj))
			return "success";
		else
			return "adduser";
		
	}
	
	

}
