package com.virtusa.banking.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.banking.dao.interfaces.HSBCUserDao;
import com.virtusa.banking.models.HSBCUser;

@Service
public class HSBCUserService {
	
	@Autowired
	private HSBCUserDao userDao;
	


	public boolean addUser(HSBCUser user)
	{
		return userDao.addUser(user);
	}
	
	
	public List<HSBCUser> getAllUsers()
	{
		return userDao.getAllUsers();
	}
	
	public HSBCUser getUserByMobileNo(long mobileNo)
	{
		return userDao.getUserByMobileNumber(mobileNo);
	}

}
